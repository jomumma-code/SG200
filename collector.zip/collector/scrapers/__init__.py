"""Scraper client modules used by the collector."""
